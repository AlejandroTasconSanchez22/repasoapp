package co.com.cesde.repasoapp;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnIrRegistro;
    Button btnIrInicioSesion;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnIrRegistro = findViewById(R.id.btn_ir_registro);
        btnIrInicioSesion = findViewById(R.id.btn_ir_iniciarSession);

        btnIrRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IrRegistro();
            }
        });

        btnIrInicioSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IrIniciarSession();
            }
        });





        }

        //Metodos Propios

    public void IrRegistro(){

        Intent intent = new Intent(this, Registro.class);
        startActivity(intent);
    }

    public void IrIniciarSession(){
        Intent intent = new Intent(this,IniciarSession.class);
        startActivity(intent);
    }



}