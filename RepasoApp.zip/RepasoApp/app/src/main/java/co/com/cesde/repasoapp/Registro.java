package co.com.cesde.repasoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseExceptionMapper;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registro extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    DatabaseReference reference = database.getReference().child("Usuarios");



    //1. Crear los Objetos de los componentes Xml

    EditText inputId;
    EditText inputNombre;
    EditText inputApellido;
    EditText inputTelefono;
    EditText inputCorreo;
    EditText inputClave;
    Button btnCrearUsuario;
    Button btnVolver_desde_Reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);


        // 2. MAPEAR LOS OBJETOS CON LOS COMPONENTES

        inputId = findViewById(R.id.input_identificacion);
        inputNombre = findViewById(R.id.input_Nombre);
        inputApellido = findViewById(R.id.Input_Apellido);
        inputTelefono = findViewById(R.id.input_numerodetelefono);
        inputCorreo = findViewById(R.id.input_Correo);
        inputClave = findViewById(R.id.input_Contraseña);
        btnCrearUsuario = findViewById(R.id.btn_Crear);
        btnVolver_desde_Reg = findViewById(R.id.btn_VolverDesdeRegistro);


        //3. Crear el evento desde los botones

        btnVolver_desde_Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                volverInicio();
            }
        });

        btnCrearUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                registrarUsuario();

            }
        });



    }

    public void volverInicio(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void registrarUsuario(){

        String telefono = inputTelefono.getText().toString();

        DatabaseReference nuevoUsuario = reference.child(String.valueOf(telefono));

        int id = Integer.parseInt(inputId.getText().toString());
        nuevoUsuario.child("Id").setValue(id);

        String nombre = inputNombre.getText().toString();
        nuevoUsuario.child("Nombre").setValue(nombre);

        String apellido = inputApellido.getText().toString();
        nuevoUsuario.child("Apellido").setValue(apellido);

        String telefonoUsuario = inputTelefono.getText().toString();
        nuevoUsuario.child("Telefono").setValue(telefonoUsuario);

        String correo = inputCorreo.getText().toString();
        nuevoUsuario.child("Telefono").setValue(correo);

        String clave = inputClave.getText().toString();
        nuevoUsuario.child("Telefono").setValue(clave);


        Toast.makeText(getApplicationContext(),"El Usuario se a creado Correctamente",Toast.LENGTH_LONG).show();
        Intent intent  = new Intent(this,MainActivity.class);
        startActivity(intent);




    }



}